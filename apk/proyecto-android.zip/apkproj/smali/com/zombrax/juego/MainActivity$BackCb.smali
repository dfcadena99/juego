.class Lcom/zombrax/juego/MainActivity$BackCb;
.super Ljava/lang/Object;
.source "MainActivity.java"

# implements ValueCallback: recibe la respuesta del juego al pulsar atrás
.implements Landroid/webkit/ValueCallback;

.field final a:Lcom/zombrax/juego/MainActivity;

.method constructor <init>(Lcom/zombrax/juego/MainActivity;)V
    .registers 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lcom/zombrax/juego/MainActivity$BackCb;->a:Lcom/zombrax/juego/MainActivity;
    return-void
.end method

.method public onReceiveValue(Ljava/lang/Object;)V
    .registers 4
    const-string v0, "\"exit\""
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v0
    if-eqz v0, :cond_0
    iget-object v1, p0, Lcom/zombrax/juego/MainActivity$BackCb;->a:Lcom/zombrax/juego/MainActivity;
    invoke-virtual {v1}, Lcom/zombrax/juego/MainActivity;->finish()V
    :cond_0
    return-void
.end method
